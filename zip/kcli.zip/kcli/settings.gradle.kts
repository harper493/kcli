
rootProject.name = "kcli2"

